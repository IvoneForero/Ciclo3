package Reto3.Reto3.repositorios.CRUD;

import Reto3.Reto3.entidades.Category;
import org.springframework.data.repository.CrudRepository;

public interface RepositoryCrudCategory extends CrudRepository<Category,Integer> {
}
