package Reto3.Reto3.repositorios.CRUD;

import Reto3.Reto3.entidades.Client;
import org.springframework.data.repository.CrudRepository;

public interface RepositoryCrudClient extends CrudRepository<Client, Integer> {
}
