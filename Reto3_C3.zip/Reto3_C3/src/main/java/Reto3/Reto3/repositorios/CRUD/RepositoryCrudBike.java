package Reto3.Reto3.repositorios.CRUD;

import Reto3.Reto3.entidades.Bike;
import org.springframework.data.repository.CrudRepository;

public interface RepositoryCrudBike extends CrudRepository<Bike, Integer> {
}
